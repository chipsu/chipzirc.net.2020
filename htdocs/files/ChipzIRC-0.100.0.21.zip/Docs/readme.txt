ChipzIRC Readme

For information & questions, please visit http://chipzirc.net/
